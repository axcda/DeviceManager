package zjc.devicemanage.model;
import java.util.ArrayList;
import java.util.List;
public class ShopingcartList {
    private List<Shopingcart> result = new ArrayList<Shopingcart>();
    public List<Shopingcart> getResult() {
        return result;
    }
    public void setResult(List<Shopingcart> result) {
        this.result = result;
    }
}