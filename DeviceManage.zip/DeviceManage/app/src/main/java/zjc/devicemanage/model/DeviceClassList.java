package zjc.devicemanage.model;
import java.util.ArrayList;
import java.util.List;
public class DeviceClassList {
    private List<DeviceClass> result = new ArrayList<DeviceClass>();
    public List<DeviceClass> getResult() {
        return result;
    }
    public void setResult(List<DeviceClass> result) {
        this.result = result;
    }
}
