package zjc.devicemanage.model;
public class Information {
    private String InformationID;
    private String InformationContent;
    private String InformationImage;
    private String InformationCreateTime;
    public String getInformationID() {
        return InformationID;
    }
    public void setInformationID(String informationID) {
        InformationID = informationID;
    }
    public String getInformationContent() {
        return InformationContent;
    }
    public void setInformationContent(String informationContent) {
        InformationContent = informationContent;
    }

    public String getInformationImage() {
        return InformationImage;
    }
    public void setInformationImage(String informationImage) {
        InformationImage = informationImage;
    }
    public String getInformationCreateTime() {
        return InformationCreateTime;
    }
    public void setInformationCreateTime(String informationCreateTime) {
        InformationCreateTime = informationCreateTime;
    }
}