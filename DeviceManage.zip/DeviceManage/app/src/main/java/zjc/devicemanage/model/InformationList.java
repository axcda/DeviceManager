package zjc.devicemanage.model;

import java.util.ArrayList;

import java.util.List;

public class InformationList {

    private List<Information> result = new ArrayList<Information>();

    public List<Information> getResult() {

        return result;

    }

    public void setResult(List<Information> result) {

        this.result = result;

    }

}