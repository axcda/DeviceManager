package zjc.devicemanage.model;
public class DeviceClass {
    private String DeviceClassID;
    private String DeviceClassName;
    public String getDeviceClassID() {
        return DeviceClassID;
    }
    public void setDeviceClassID(String deviceClassID) {
        DeviceClassID = deviceClassID;
    }
    public String getDeviceClassName() {
        return DeviceClassName;
    }
    public void setDeviceClassName(String deviceClassName) {
        DeviceClassName = deviceClassName;
    }
}
